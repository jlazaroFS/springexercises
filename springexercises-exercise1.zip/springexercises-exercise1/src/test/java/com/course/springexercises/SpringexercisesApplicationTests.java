package com.course.springexercises;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringexercisesApplicationTests {

	@Test
	void contextLoads() {
	}

}
